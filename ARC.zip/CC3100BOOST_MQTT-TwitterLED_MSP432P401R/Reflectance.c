#include <stdint.h>
#include "msp432.h"
#include "..\inc\Clock.h"

// ------------Reflectance_Init------------
// Initialize the GPIO pins associated with the QTR-8RC
// reflectance sensor.  Infrared illumination LEDs are
// initially off.
// Input: none
// Output: none
void Reflectance_Init(void)
{
    // Setting Pins as GPIO
    // P7 is For Sensors - Initially Inputs
    P7->SEL0 &=~ 0xFF;
    P7->SEL1 &=~ 0xFF;
    P7->DIR  &=~ 0xFF;
    // P5 is CTRL EVEN - Output
    P5->SEL0 &=~ 0x08;
    P5->SEL1 &=~ 0x08;
    P5->DIR  |=  0x08;
    P5->OUT  &=~ 0x08;
    // P9 is CTRL ODD  - Output
    P9->SEL0 &=~ 0x04;
    P9->SEL1 &=~ 0x04;
    P9->DIR  |=  0x04;
    P9->OUT  &=~ 0x04;

}

// ------------Reflectance_Read------------
// Read the eight sensors
// Turn on the 8 IR LEDs
// Pulse the 8 sensors high for 10 us
// Make the sensor pins input
// wait t us
// Read sensors
// Turn off the 8 IR LEDs
// Input: time to wait in usec
// Output: sensor readings
// Assumes: Reflectance_Init() has been called
uint8_t Reflectance_Read(uint32_t time){
    uint8_t result;

    P5->OUT |= 0x08;      // turn on 4 even IR LEDs
    P9->OUT |= 0x04;      // turn on 4 odd IR LEDs
    P7->DIR |= 0xFF;       // make P7.7-P7.0 out
    P7->OUT |= 0xFF;       // prime for measurement
    Clock_Delay1us(10);   // wait 10 us
    P7->DIR &=~0xFF;       // make P7.7-P7.0 in
    Clock_Delay1us(time);
    result = P7->IN&0xFF; // convert P7.7-P7.0 input to digital
    P5->OUT &= ~0x08;     // turn off 4 even IR LEDs
    P9->OUT &= ~0x04;      // turn off 4 odd IR LEDs
    return result;
}

//// ------------Reflectance_Center------------
//// Read the two center sensors
//// Turn on the 8 IR LEDs
//// Pulse the 8 sensors high for 10 us
//// Make the sensor pins input
//// wait t us
//// Read sensors
//// Turn off the 8 IR LEDs
//// Input: time to wait in usec
//// Output: 0 (off road), 1 off to left, 2 off to right, 3 on road
//// (Left,Right) Sensors
//// 1,1          both sensors   on line
//// 0,1          just right     off to left
//// 1,0          left left      off to right
//// 0,0          neither        lost
//// Assumes: Reflectance_Init() has been called
//uint8_t Reflectance_Center(uint32_t time){
//    // write this as part of Lab 6
//  return 0; // replace this line
//}


// Perform sensor integration
// Input: data is 8-bit result from line sensor
// Output: position in 0.1mm relative to center of line
int32_t Reflectance_Position(uint8_t data)
{
    // First we get a matrix for the hex values of each IR LED
    uint8_t bi [8] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
    int32_t wi [8] = {-33400,-23800,-14300,-4800,4800,14300,23800,33400};
   int total = 0;
    int32_t dist = 0;
   uint32_t avg = 0;
   // Anding together the bi Matrix and the data vector will
   // yield a 1 in place where the sensor is on
   int i;
   for (i=0; i<8; i++)
   {
       // Bitwise And Will Check WIth Every Bit in the data
       // Returns True if the specific sensor that is on is
       // is the same as the matrix position of bi[i]
       if (bi[i]&data)
       {
           total++;
           dist += wi[i];
       }
   }
   avg = dist/total;
 return avg;
}


// ------------Reflectance_Start------------
// Begin the process of reading the eight sensors
// Turn on the 8 IR LEDs
// Pulse the 8 sensors high for 10 us
// Make the sensor pins input
// Input: none
// Output: none
// Assumes: Reflectance_Init() has been called
void Reflectance_Start(void)
{
    P5->OUT |= 0x08;      // turn on 4 even IR LEDs
    P9->OUT |= 0x04;      // turn on 4 odd IR LEDs
    P7->DIR |= 0xFF;       // make P7.7-P7.0 out
    P7->OUT |= 0xFF;       // prime for measurement
    Clock_Delay1us(10);   // wait 10 us
    P7->DIR &=~0xFF;       // make P7.7-P7.0 in
}


// ------------Reflectance_End------------
// Finish reading the eight sensors
// Read sensors
// Turn off the 8 IR LEDs
// Input: none
// Output: sensor readings
// Assumes: Reflectance_Init() has been called
// Assumes: Reflectance_Start() was called 1 ms ago
uint8_t Reflectance_End(void)
{
    uint8_t result;
    result = P7->IN&0xFF; // convert P7.7-P7.0 input to digital
    P5->OUT &= ~0x08;     // turn off 4 even IR LEDs
    P9->OUT &= ~0x04;      // turn off 4 odd IR LEDs
    return result;
}

